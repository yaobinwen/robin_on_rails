 window.is_euro_union = 0;
 window.country_code2 = "US";
 window.country_code3 = "USA";
 window.region = "PA";